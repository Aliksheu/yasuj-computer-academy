
document.querySelectorAll('.menu').forEach(b=>b.addEventListener('click',()=>{
 const nav=document.querySelector('.mobile-nav'); nav.classList.toggle('show');
}));
document.querySelectorAll('.faq-q').forEach(q=>q.addEventListener('click',()=>{
 const item=q.parentElement; item.classList.toggle('open');
 q.querySelector('span').textContent=item.classList.contains('open')?'−':'+';
}));
document.querySelectorAll('[data-year]').forEach(e=>e.textContent=new Date().getFullYear());
